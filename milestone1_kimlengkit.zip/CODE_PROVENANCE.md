# CODE PROVENANCE

## Student info
- Name: Kimleng Kit
- NetID: 33834069
- Date: 2025-11-03

## Tools used
- ChatGPT, GPT-5 Thinking, Google Chrome, Lecture Slide, Previous Homeowork

## Prompts and outputs you used

### Purpose: Choose and generate a .gitignore for Python/FastAPI/Docker services
- **Prompt:** "what gitignore template should I use"
    - **Output used:** Root `.gitignore` patterns for Python, virtualenvs, Docker volumes, IDE files
    - **File and lines:** .gitignore (entire file)
    - **Modifications:** Adjusted directory names to match this repo’s structure

### Purpose: Mermaid diagram formatting (line breaks + proper rendering)
- **Prompt:** “In Mermaid flowchart, how do I add a new line inside a node label?”
    - **Output used:** Use `\n` inside quoted labels, `["auth-service\nGET /health"]`.
    - **File and lines:** `architecture-diagram.md` (node labels)
    - **Modifications:** Replaced `<br/>` with `\n`.

- **Prompt:** “Why isn’t my Mermaid diagram rendering in VS Code?”
    - **Output used:** Wrap in triple backticks with `mermaid`; first line must be `flowchart TB`; ensure `subgraph` is on one line. Optionally install “Markdown Preview Mermaid Support.”
    - **File and lines:** `architecture-diagram.md` (entire block)
    - **Modifications:** Fixed code fences and `subgraph` header; exported PNG.

### Purpose: Health behavior for user-service (policy)

- **Prompt:** “What timeout should I use for internal health calls between services?”
- **Output used:** Use a **~2.0s** request timeout for `httpx` health calls.
- **File and lines:** `user-service/app/main.py` (timeout value)
- **Modifications:** Set `timeout=2.0`.

### Purpose: Validation handler style
- **Prompt:** “How should I respond to validation errors in FastAPI?”
- **Output used:** Return JSON with short, friendly message; use 400
- **File and lines:** None
- **Modifications:** Added lightweight `RequestValidationError` handler where used

### Purpose: Docker Compose healthchecks for services
- **Prompt:** “What’s a simple healthcheck command for FastAPI?”
- **Output used:** `curl -f http://localhost:8000/health`
- **File and lines:** `docker-compose.yml`
- **Modifications:** Add commands to `README.md` for testing health endpoints.

### Purpose: Project structure presentation
- **Prompt:** “How should I present the repo structure?”
- **Output used:** ASCII tree with brief descriptions
- **File and lines:** `README.md` (Project Structure)
- **Modifications:** Matched actual folders/files from the repo

### Purpose: Commit message convention for health work
- **Prompt:** “What are commit messages for each health endpoint implementation for auth-service container, user-service that depends on auth-service, post-service that depends on auth and user, and comment-service that depends on user and post?”
- **Output used:** 
  - `feat: add health endpoint to auth-service`
  - `feat: implement user-service health check with auth dependency`
  - `feat: add post-service health check with auth and user dependencies`
  - `feat: add comment-service health check with user and post dependencies`
- **File and lines:** None
- **Modifications:** Used as guidance during commits

### Purpose: Testing guidance for manual verification
- **Prompt:** “What minimal manual test steps demonstrate correct health behavior?”
- **Output used:** `docker compose stop <dep>` then `curl` dependent `/health` to see 503; restart and verify 200
- **File and lines:** `README.md` (Testing)
- **Modifications:** Added stop/start examples and expected outcomes

### Purpose: Pydantic dict defaults (v2)
- **Prompt:** “In Pydantic, what’s the right way to set a dict default and why is `default_factory=dict` preferred?”
- **Output used:** Use `Field(default_factory=dict)` to avoid shared mutable defaults.
- **File and lines:** `*/app/health_models.py`
- **Modifications:** Replaced any bare `{}` with `default_factory`.

### Purpose: Async vs sync for health calls
- **Prompt:** “Should health calls be async or sync in FastAPI, and what are the trade-offs?”
- **Output used:** Prefer async for concurrency; keep endpoints fast with short timeouts.
- **File and lines:** `*/app/main.py`
- **Modifications:** Implemented dependency checks with `async` + `httpx.AsyncClient`.

### Purpose: Docker networking/service discovery
- **Prompt:** “How do containers discover each other by service name in Docker Compose, and why can they all listen on port 8000?”
- **Output used:** Internal DNS gives unique IPs per service; same internal port is fine across containers.
- **File and lines:** None
- **Modifications:** None

### Purpose: Minimal error details in dependency health
- **Prompt:** “What minimal error details should I include?”
- **Output used:** Short exception string in `error`; keep null on success.
- **File and lines:** `*/app/health_models.py`, `*/app/main.py`
- **Modifications:** Populated `error` only on failure.

### Purpose: Document usage without exposed host ports
- **Prompt:** “How should I document calling `/health` when each service listens only inside its container?”
- **Output used:** Use `docker compose exec <service> curl http://localhost:8000/health`.
- **File and lines:** `README.md` (Usage Instructions)
- **Modifications:** Removed gateway routing examples and added direct container commands.

### Purpose: Measure dependency call latency accurately
- **Prompt:** “Why use time.perf_counter() instead of time.time()?”
- **Output used:** Use `time.perf_counter()` for high-resolution monotonic timing and convert to ms.
- **File and lines:** */app/main.py (health timing)
- **Modifications:** Replaced `time.time()` deltas with `perf_counter()` and `* 1000`.

### Purpose: Structure a reusable dependency checker
- **Prompt:** “What’s a clean helper signature for checking another service’s /health with httpx?”
- **Output used:** `async def check_dependency(base_url: str) -> DependencyHealth`
- **File and lines:** post-service/app/main.py, comment-service/app/main.py
- **Modifications:** Centralized httpx call + exception mapping in one helper.

### Purpose: Map httpx errors into the health schema
- **Prompt:** “How should RequestError vs non 200 status map into DependencyHealth?”
- **Output used:** On RequestError → `status="unhealthy"`, set `error=str(exc)`; on non-200 → `status="unhealthy"` without stack traces.
- **File and lines:** */app/main.py (try/except around httpx)
- **Modifications:** Added explicit except for `httpx.RequestError`; used `response.status_code` for non-200 branch.

### Purpose: Ensure consistent HTTP codes for /health
- **Prompt:** “How do I guarantee 200 when all deps are healthy and 503 otherwise?”
- **Output used:** Compute `overall_status` from deps; `http_status = 200 if overall == "healthy" else 503`.
- **File and lines:** */app/main.py (endpoint return)
- **Modifications:** Wrapped final payload with `JSONResponse(status_code=http_status, content=...)`.

### Purpose: Constrain status to specific literals
- **Prompt:** “How do I restrict status to 'healthy'|'unhealthy' in Pydantic?”
- **Output used:** `Status = Literal["healthy", "unhealthy"]` and reference it in models.
- **File and lines:** */app/health_models.py
- **Modifications:** Added `Status` alias and updated field types.

### Purpose: Defensive JSON serialization
- **Prompt:** “Should I return model instances or explicit JSONResponse?”
- **Output used:** Use `JSONResponse(content=model.model_dump())` when custom status codes are required.
- **File and lines:** */app/main.py (/health return)
- **Modifications:** Replaced bare return of model with explicit `JSONResponse`.

### Purpose: Ensure event loop-safe httpx usage
- **Prompt:** “Is it safe to create a new AsyncClient per request for health, or should I reuse one?”
- **Output used:** For simplicity, create per call; keep short timeout; OK for low-QPS health.
- **File and lines:** */app/main.py (check_dependency helper)
- **Modifications:** Used context manager per call.

## High-level influence
- Used AI suggestions for choosing consistent env var and service naming patterns, but wrote the actual implementations myself.

## Non-AI sources
- [FastAPI docs](https://fastapi.tiangolo.com/): endpoint patterns and responses 
- [Pydantic v2 docs](https://docs.pydantic.dev/): BaseModel usage and `Field(default_factory=...)` 
- [httpx docs](https://www.python-httpx.org/): async client, timeouts, exceptions
- [Docker](https://docs.docker.com/) and [Docker Compose](https://docs.docker.com/compose/): service networking and `depends_on` health conditions
- [Mermaid docs](https://mermaid.js.org/): flowchart syntax for the architecture diagram
- [NGINX docs](https://nginx.org/en/docs/): nginx configuration
- **Course materials (Lecture Slides and Homework 3)**: nginx, Docker, Docker Compose
    - **Docker containerization and healthchecks**: Homework 3 set up guidance
    - **Docker Compose orchestration, service dependencies, internal DNS**: Homework 3 instructions 


## Originality Statement
 
- I affirm that I understand the course policy on authorized assistance.
- All external and AI assistance is fully documented above.
- I take responsibility for the submitted code and can explain it.

Signature: Kimleng Kit Date: 2025-11-03